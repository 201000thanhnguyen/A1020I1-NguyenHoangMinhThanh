interface IStudent {
  id: number;
  name: string;
  birthDay: string;
  studentClass: IClass;
}
