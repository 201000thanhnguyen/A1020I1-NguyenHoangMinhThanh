interface IClass {
  id: number;
  className: string;
}
