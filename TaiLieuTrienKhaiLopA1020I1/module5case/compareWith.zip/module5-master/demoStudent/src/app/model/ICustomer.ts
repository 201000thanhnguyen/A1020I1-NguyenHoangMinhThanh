interface ICustomer {
  id: number;
  name: string;
  birthDay: string;
  customerType: ICustomerType;
}
