interface ICustomerType {
  id: number;
  customerTypeName: string;
}
